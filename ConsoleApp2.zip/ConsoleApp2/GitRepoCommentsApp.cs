﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NsGitRepoCommentsApp
{
    public class GitRepoCommentsApp
    {
        Node root;
        List<string> oList = new List<string>();
        StringBuilder oSB = new StringBuilder();
        public class Node
        {
            public int key;
            public string skeyValue;
            public Node left, right;

            public Node(int item, string svalue)
            {
                key = item;
                skeyValue = svalue;
                left = right = null;
            }
        }

        public GitRepoCommentsApp()
        {
            root = null;
        }

        public void insert(int key, string svalue)
        {
            root = insertRec(root, key, svalue);
        }

        Node insertRec(Node root, int key, string svalue)
        {
            if (root == null)
            {
                root = new Node(key, svalue);
                return root;
            }
            if (key < root.key)
                root.left = insertRec(root.left, key, svalue);
            else if (key > root.key)
                root.right = insertRec(root.right, key, svalue);
            return root;
        }
        public List<string> inorder()
        {
            inorderRec(root);
            oList.Add(oSB.ToString());
            return oList;
        }

        void inorderRec(Node root)
        {
            if (root != null)
            {
                inorderRec(root.left);
                oSB.Append(root.skeyValue + " ");
                inorderRec(root.right);
            }
        }

    }
}
