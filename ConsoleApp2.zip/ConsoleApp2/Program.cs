﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Data;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Net;

namespace NsGitRepoCommentsApp
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Task.WaitAll(ExecuteAsync());
            }
            catch (Exception)
            {
                Console.WriteLine("\nIncorrect Details, Please provide valid inputs.\n");
                Task.WaitAll(ExecuteAsync());
            }
        }

        public static async Task ExecuteAsync()
        {
            try
            {
                List<string> olistString;
                List<string> soretedlist;

                Console.WriteLine("\n**** Please Enter Github Details ****\n");
                Console.WriteLine("\nPlease enter Github Username:");
                string sUsername = Console.ReadLine();
                Console.WriteLine("\nPlease enter Github Access-Token:");
                string sAccessToken = Console.ReadLine();
                Console.WriteLine("\nPlease enter Github Repository Name:");
                string sRepoName = Console.ReadLine();

                string sURL = "https://api.github.com/repos/" + sUsername + "/" + sRepoName + "/" + "commits";
                var data = new JArray();
                System.Net.Http.HttpClient client = new HttpClient();
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/vnd.github.v3+json"));
                client.DefaultRequestHeaders.Add("User-Agent", "GitRepoCommentsApp");
                client.DefaultRequestHeaders.Add("Authorization", "Token " + sAccessToken);

                var stringTask = client.GetStringAsync(sURL);
                var jsonString = await stringTask;

                olistString = GetMessagesFromCommits(jsonString);
                soretedlist = BinarySortbasedOnASCIICode(olistString);
                DisplayValuesToScreen(soretedlist);
            }
            catch (Exception)
            {
                Console.WriteLine("Log Errors");
                throw;
            }
        }

        static void DisplayValuesToScreen(List<string> SoretedList)
        {
            try
            {
                Dictionary<string, int> oDicCommits = new Dictionary<string, int>();
                StringBuilder oStringB = new StringBuilder();
                foreach (var item in SoretedList)
                {
                    oStringB.Append(item + " ");
                }

                char[] chars = { ' ', '.', ',', ';', ':', '?', '\n', '\r' };
                string[] words = oStringB.ToString().Split(chars);
                int minWordLength = 2;
                foreach (string word in words)
                {
                    string w = word.Trim().ToLower();
                    if (w.Length > minWordLength)
                    {
                        if (!oDicCommits.ContainsKey(w))
                        {
                            oDicCommits.Add(w, 1);
                        }
                        else
                        {
                            oDicCommits[w] += 1;
                        }
                    }
                }

                var orderedStats = oDicCommits.OrderBy(x => x.Key);
                Console.WriteLine("\n\n ****  Output **** \n");
                Console.WriteLine("\n Total Occurrences Of Words: \n");
                foreach (var pair in orderedStats)
                {
                    Console.WriteLine(" {0}: {1}", pair.Key, pair.Value);
                }

                Console.WriteLine(" \n\n Total word count: {0}", oDicCommits.Count + "\n\n");
                Console.WriteLine("\n**** Export Data To CSV File ****\n");
                Console.WriteLine("Would you like to export data to CSV file: (Yes/No) :");
                string sExportResponse = Console.ReadLine();

                if (sExportResponse.ToLower() == "yes")
                {
                    DownloadCSVFile(oDicCommits);
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Log Errors");
                throw;
            }
        }

        public static void DownloadCSVFile(Dictionary<string, int> oDic)
        {
            try
            {
                string pathToCsv = @"C:\GitRepoFiles\ExportGitHubRepoComments.csv";
                string delimiter = ", ";
                string createText = "Words" + delimiter + "Occurrences" + delimiter + Environment.NewLine;
                if (!File.Exists(pathToCsv))
                {
                    File.WriteAllText(pathToCsv, createText);

                }
                else
                {
                    File.Delete(pathToCsv);
                    File.WriteAllText(pathToCsv, createText);
                }

                foreach (var item in oDic)
                {
                    string appendText = item.Key + delimiter + item.Value + delimiter + Environment.NewLine;
                    File.AppendAllText(pathToCsv, appendText);
                }
                Console.WriteLine("\n **** Data Exported succesfully, Please find CSV file at C drive GitRepoFiles folder with file name of ExportGitHubRepoComments  **** ");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Log Errors");
                throw;
            }
        }


        public static List<string> BinarySortbasedOnASCIICode(List<string> ostring)
        {
            List<string> sortedcommitbasedon = new List<string>();
            try
            {
                List<string> sortedcommitbasedonascii;
                String[] arr = ostring.ToArray();
                int n = arr.Length;

                foreach (var itemList in ostring)
                {
                    GitRepoCommentsApp tree = new GitRepoCommentsApp();
                    sortedcommitbasedonascii = new List<string>();
                    var splitrow = itemList.Split();
                    foreach (var splitItem in splitrow)
                    {
                        byte[] asciiBytes = Encoding.ASCII.GetBytes(splitItem);
                        int makeitsum = 0;
                        foreach (var item in asciiBytes)
                        {
                            makeitsum = makeitsum + item;
                        }
                        tree.insert(makeitsum, splitItem);
                    }
                    sortedcommitbasedonascii = tree.inorder();
                    sortedcommitbasedon.AddRange(sortedcommitbasedonascii);
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Log Errors");
                throw;
            }
            return sortedcommitbasedon;
        }
        public static List<string> GetMessagesFromCommits(string json)
        {
            List<string> otrgArray = new List<string>();
            try
            {
                DataTable oData = new DataTable();
                var trgArray = new JArray();
                JArray jsonArray = JArray.Parse(json);
                foreach (JObject row in jsonArray.Children<JObject>())
                {
                    var query = row.Descendants()
                                    .OfType<JProperty>()
                                    .Where(p => p.Value.Type != JTokenType.Array && p.Value.Type != JTokenType.Object);
                    var cleanRow = new JObject();
                    var jArray = new JArray();
                    foreach (JProperty column in query)
                    {
                        string stringvalue = "";
                        if (column.Value is JValue)
                        {
                            if (column.Name == "message")
                            {
                                stringvalue = (string)column.Value;
                                otrgArray.Add(stringvalue);
                            }
                        }
                    }
                }
                Console.WriteLine(otrgArray);
                return otrgArray;
            }
            catch (Exception)
            {

                throw;
            }

            return otrgArray;
        }
    }
}

